package com.example.drawing;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class ColorTileView extends View {

    public ColorTileView(Context context) {
        super(context);
    }

    public ColorTileView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public ColorTileView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setColor(int color) {
        GradientDrawable drawable = (GradientDrawable) getBackground();
        drawable.setColor(color);
    }

    public void setBorderColor(int color) {
        GradientDrawable drawable = (GradientDrawable) getBackground();
        drawable.setStroke(2, color);
    }
}
