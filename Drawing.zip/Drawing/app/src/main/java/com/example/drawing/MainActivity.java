package com.example.drawing;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DrawingView drawingView;
    private ColorTileView redTile, greenTile, blueTile, blackTile, whiteTile, grayTile, yellowTile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawingView = findViewById(R.id.drawingView);

        redTile = findViewById(R.id.pen_color_red);
        greenTile = findViewById(R.id.pen_color_green);
        blueTile = findViewById(R.id.pen_color_blue);
        blackTile = findViewById(R.id.pen_color_black);

        whiteTile = findViewById(R.id.bg_color_white);
        grayTile = findViewById(R.id.bg_color_gray);
        yellowTile = findViewById(R.id.bg_color_yellow);

        redTile.setColor(Color.RED);
        greenTile.setColor(Color.GREEN);
        blueTile.setColor(Color.BLUE);
        blackTile.setColor(Color.BLACK);

        whiteTile.setColor(Color.WHITE);
        grayTile.setColor(Color.LTGRAY);
        yellowTile.setColor(Color.YELLOW);

        redTile.setOnClickListener(v -> {
            drawingView.setPaintColor(Color.RED);
            updatePenColorSelection(redTile);
        });
        greenTile.setOnClickListener(v -> {
            drawingView.setPaintColor(Color.GREEN);
            updatePenColorSelection(greenTile);
        });
        blueTile.setOnClickListener(v -> {
            drawingView.setPaintColor(Color.BLUE);
            updatePenColorSelection(blueTile);
        });
        blackTile.setOnClickListener(v -> {
            drawingView.setPaintColor(Color.BLACK);
            updatePenColorSelection(blackTile);
        });

        whiteTile.setOnClickListener(v -> {
            drawingView.setBackgroundColor(Color.WHITE);
            updateBackgroundColorSelection(whiteTile);
        });
        grayTile.setOnClickListener(v -> {
            drawingView.setBackgroundColor(Color.LTGRAY);
            updateBackgroundColorSelection(grayTile);
        });
        yellowTile.setOnClickListener(v -> {
            drawingView.setBackgroundColor(Color.YELLOW);
            updateBackgroundColorSelection(yellowTile);
        });

        updatePenColorSelection(blackTile);
        updateBackgroundColorSelection(whiteTile);
    }

    private void updatePenColorSelection(ColorTileView selectedTile) {
        redTile.setBorderColor(Color.TRANSPARENT);
        greenTile.setBorderColor(Color.TRANSPARENT);
        blueTile.setBorderColor(Color.TRANSPARENT);
        blackTile.setBorderColor(Color.TRANSPARENT);

        selectedTile.setBorderColor(Color.BLACK);
    }

    private void updateBackgroundColorSelection(ColorTileView selectedTile) {
        whiteTile.setBorderColor(Color.TRANSPARENT);
        grayTile.setBorderColor(Color.TRANSPARENT);
        yellowTile.setBorderColor(Color.TRANSPARENT);

        selectedTile.setBorderColor(Color.BLACK);
    }
}
